﻿namespace battleship.enums
{
    public enum Position
    {
        Vertical,
        Horizontal
    }
}