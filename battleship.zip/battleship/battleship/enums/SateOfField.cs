﻿namespace battleship.enums
{
    public enum SateOfField
    {
        Fired,// ostrzelane pole bez statku
        Free,// wolne pole
        Hit,// uderzony
        HitSunk // trafiony zatopiony
        
    }
}