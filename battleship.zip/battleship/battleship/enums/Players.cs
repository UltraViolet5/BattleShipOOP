﻿namespace battleship.enums
{
    public enum Players
    {
        FirstPlayer,
        SecondPlayer
    }
}