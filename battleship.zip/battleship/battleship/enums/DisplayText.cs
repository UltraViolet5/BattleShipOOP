﻿namespace battleship.enums
{
    public enum DisplayText
    {
        WelcomeGraphic,
        WelcomeMenu,
        InfoAboutGame,
        BoardSizeInput

    }
}